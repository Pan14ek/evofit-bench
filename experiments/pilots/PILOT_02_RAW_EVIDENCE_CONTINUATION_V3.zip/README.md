# PILOT-02 V3 raw evidence continuation

Evidence class: TEST_ONLY DEVELOPMENT; one A0_MONOLITH to A0_1_CAPABILITY_MODULES transition.
Run ID: pilot02-a01-ci-20261020-v3
Method P source revision: a5eaeb376aa069749e537af7f9f73eea10abe5d0
Prospective corrected TEST_ONLY continuation on the same A0 to A0.1 transition. It is not an independent sample.

The `method_p_run/` directory preserves the Method P output, verified input, trace, candidate, raw evaluator outputs, per-file run manifest, and its digest. V3 also includes the EXP-01/EXP-02 run directory in `exp01_exp02_run/`.

Commands (the experiment was executed with the bundled Python 3.12 runtime and repository site-packages):

`python -m scripts.exp01_evidence --architecture-state A0_1_CAPABILITY_MODULES --run-id pilot02-a01-ci-20261020-v3 --skip-deployment-observation`
`python -m scripts.exp02_fitness_evidence --run-dir experiments/results/pilot02-a01-ci-20261020-v3`
`python -m experiments.pilots.run_pilot02_method_p --exp02-run-dir experiments/results/pilot02-a01-ci-20261020-v3 --output-dir /private/tmp/pilot02-corrected-v3-20261020 --test-only-continuation --test-only-assumptions experiments/pilots/PILOT_02_DEVELOPMENT_ASSUMPTIONS_V2.json`

The experiment does not supply DA01 oracle/scorer data, does not establish Coverage_P or Coverage_ref, and does not change G1/G4 or Method P readiness.
