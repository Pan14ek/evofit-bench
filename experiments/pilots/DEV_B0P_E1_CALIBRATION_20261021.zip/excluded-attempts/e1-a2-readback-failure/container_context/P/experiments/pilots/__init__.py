"""TEST_ONLY verifier support for isolated B0/P runs."""
