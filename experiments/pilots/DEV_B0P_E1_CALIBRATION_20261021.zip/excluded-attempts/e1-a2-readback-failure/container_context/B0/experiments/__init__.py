"""Isolated EvoFitBench runtime package."""
