# DEV-B0P-V1 E1 calibration evidence package

Primary run: `b0p-e1-cal-20261021-a4` at source revision `14fc8b1bbec2aad2f2968e96e04a02b81a9ed720`.

`primary/e1-run.zip` is the E1 tool-generated archive; its adjacent sidecar records its SHA-256. `primary/e1-run-directory/` is the source run directory used for clean readback. The fresh inherited evaluator run and EXP-01 run are included separately, along with the exact P input preparation, TEST_ONLY adaptation sidecar, semantic control evidence, preparation snapshot, frozen reference and normative protocols.

`excluded-attempts/` preserves two earlier runs that reached method execution but failed readback in the pre-fix verifier. They are excluded from primary results. `historical/E0_REFERENCE.json` points to immutable E0 and its existing downloadable archive; E0 payload bytes are not rewritten or duplicated here.

Verify the package with `shasum -a 256 -c SHA256SUMS`. Then compare each member to `PACKAGE_MANIFEST.json`. The inner E1 ZIP has its own sidecar and was independently extracted and verified by the E1 runner.

All TEST_ONLY artifacts are development evidence, not production policy authority or measured DA01 coverage.
