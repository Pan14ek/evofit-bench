# PILOT-02 V5 inherited-evaluator continuation evidence

Created 2026-10-20. This archive preserves one canonical completed DEVELOPMENT run and the raw outputs of three earlier technical attempts. Runs are continuations of the same A0 to A0.1 transition, not independent experimental units.

## Canonical run

`runs/pilot02-inherited-20261020-v5d/` is the canonical V5 result. It ran from clean source revision `3758e2cd60810b8d4263f8d91443ec829efc8bb5`, records `completed_development_evidence`, and its readback validator reported `validated` for all 193 inventoried artifacts. The linked standalone EXP-01 bundle is preserved under `runs/pilot02-inherited-20261020-v5d-exp01/`.

The fresh four-row evaluator observations are shared, single executions for the unchanged B0 and P-retained representations. They are not two-arm replicates. Locust measured 133 requests, 0 failures, p95 23 ms, p50 14 ms and p99 42 ms over 30.280 s. The EXP-01 runtime collection preserved 153 histogram samples, including 9 count series with total interval count delta 95 and sum delta 0.6744200020003746 seconds; no quantiles were inferred. The selected integration test passed (1 passed, 0 failures, 0 errors, 0 skipped) in 1.605 s against dedicated disposable database `evofit_pilot02_test`; credentials were not recorded. Runtime failure representation execution is partial and its evaluation is UNKNOWN: the 5xx numerator and business-operation failure series were unavailable, so no zero rate is claimed.

The full candidate validator reported `valid`; this resolves `ACTIVE_EVALUATOR_ARTIFACT_UNAVAILABLE` as an artifact-binding validation error. It does not establish semantic adequacy or exact-pair validity. Method P emitted `ADD AC_MODULE_STRUCTURE` and `REPLACE REP_A0_ARCH_CI_LAYERING`; the candidate SHA-256 is `1396dc3735e15088920ee423701021505ca1c1d37712d3b7e68a98ca5a879534`. Both target pairs remain UNKNOWN, the internal mandatory diagnostic is 0/2, governance is HOLD, `P_ALGORITHM_STATUS` is NOT_READY, G1 is INCOMPLETE and G4 is NOT AUTHORIZED.

The unchanged B0 Import Linter run was inconclusive (exit 1; configured `app.repositories` target absent; no broken-contract count). The P candidate evaluators completed (Import Linter: 5 contracts kept, 0 broken; module-structure test: 1 passed). No controlled degradation was introduced, so comparative detection behavior is not established. Runtime source-to-image provenance remains unverified. All detailed stdout/stderr, raw measurement files, run manifests, evaluator inventories, result documents, source/config hashes and Method P outputs are included in the canonical run directories.

## Earlier technical attempts preserved, excluded from primary analysis

- `attempts/pilot02-inherited-20261020-v5-initial-setup-failure/`: Docker Compose build did not start because the first local Buildx attempt lacked access to its activity directory. No evaluator ran.
- `attempts/pilot02-inherited-20261020-v5b/`: authentic evaluators and Method P ran, but result finalization failed on a runner `KeyError` (`exit_status`). The run is incomplete and is not the canonical result.
- `attempts/pilot02-inherited-20261020-v5c/` and `attempts/pilot02-inherited-20261020-v5c-exp01/`: complete technical run outputs, but the test database container ID was not recorded by that runner revision. Preserved without editing and excluded as canonical provenance evidence.

## Reproduction materials

`protocol/` contains the pre-execution evaluator inventory/protocol, exact V2 profile and TEST_ONLY assumptions, relevant schemas, and the two PILOT-02 runner sources. Reproduce from the recorded source commit and the checked-in repository; the archive contains no user-provided deployment credentials, private keys, oracle labels, ground truth, or scorer outputs. Checked-in Compose/config snapshots retain the repository’s fixed disposable-test connection defaults; the run record does not capture authentication credentials.

## Integrity

The V5 ZIP has an adjacent repository sidecar `PILOT_02_RAW_EVIDENCE_CONTINUATION_V5.zip.sha256`. The canonical `run_manifest.sha256` and artifact inventories remain inside their respective run directories. Zip member CRCs and payloads were verified at archive construction.
