# PILOT-02 V4 raw evidence continuation

Evidence class: TEST_ONLY DEVELOPMENT; one A0_MONOLITH to A0_1_CAPABILITY_MODULES transition. This is not an independent experimental unit.

Run ID: pilot02-a01-ci-20261020-v4
Method P source revision: d793c92b881f0b69321188f888fa7346c468fc3c

`method_p_run/` preserves the Method P output, verified input, trace, candidate, raw evaluator outputs, per-file run manifest, and its digest. `exp01_exp02_run/` preserves the input EXP-01 bundle, EXP-02 representation evidence, and referenced raw evaluator artifacts. The checked-in V4 addendum and unchanged V2 TEST_ONLY assumptions are included.

Commands (executed with bundled Python 3.12 and the repository's installed site-packages):

- `python -m scripts.exp01_evidence --architecture-state A0_1_CAPABILITY_MODULES --run-id pilot02-a01-ci-20261020-v4 --skip-deployment-observation`
- `python -m scripts.exp02_fitness_evidence --run-dir experiments/results/pilot02-a01-ci-20261020-v4`
- `python -m experiments.pilots.run_pilot02_method_p --exp02-run-dir experiments/results/pilot02-a01-ci-20261020-v4 --output-dir /private/tmp/pilot02-corrected-v4-20261020 --test-only-continuation --test-only-assumptions experiments/pilots/PILOT_02_DEVELOPMENT_ASSUMPTIONS_V2.json`

EXP-01 returned exit 2 because deployment was skipped and runtime evidence was missing. EXP-02 returned valid for five representations with three unresolved mappings. Method P completed TEST_ONLY and returned HOLD. The trace marks execution evidence admitted to P calculations while semantic pair proof remains absent. The archive does not contain DA01 oracle/scorer data and does not establish Coverage_P, Coverage_ref, G1/G4, or Method P readiness.
