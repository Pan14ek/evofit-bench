# PILOT-02 raw evidence continuation V6

This archive preserves the final TEST_ONLY DEVELOPMENT continuation for the single A0 → A0.1 transition, its source-bound semantic controls, all four inherited evaluator observations, the Method P sidecar and trace, the materialized candidate, evaluator readback, and the versioned protocol and implementation sources. The primary source revision is `24e9fb91161523377946e16fe5699e49955c2db4`; the A0.1 application tree SHA-1 is `cdff9a6c3cee870e1eca2a5f5f3eb3202b0b1f08`. The branch base is `3fdd5c68f8f60fad5757eefa66cc2aa8b24d9306`.

## Primary result

Both predeclared exact pairs are `VALID` and `COMPLIANT` in the TEST_ONLY Method P trace:

- `REP_A01_ARCH_INTERNAL_LAYERING_CI` → `AC_LAYERING`
- `REP_A01_ARCH_MODULE_STRUCTURE_CI` → `AC_MODULE_STRUCTURE`

The reports bind the source, obligation, exact evaluator/template and evidence-contract digests, inspection inventories, and positive/negative raw controls. Candidate materialization readback confirms both rows exactly match their prevalidated templates. The controls are mechanical TEST_ONLY evidence; `independent_human_assessment=false`.

Layering scope: all 17 configured module targets resolved; all 17 were inspected; five Import Linter contracts ran; 18 contract-relevant direct dependency edges were measured. The full Grimp graph held 50 modules and 70 direct dependencies, of which only the recorded 18 are in contract scope. The clean control kept all five contracts. The secondary PILOT-01 S1 edge control broke only Notifications (four kept, one broken); it is not a new independent architecture transition.

Module-structure scope: five modules (`audit`, `notifications`, `reporting`, `tasks`, `users`) and their exact expected package file sets were checked; no missing or unexpected files were found. The clean test passed. The predefined negative control removed `app/modules/audit/model.py` (pre-mutation SHA-256 `7017f08f13274d7d600aaa3a9c54d8eb99d441fa7addbeb2326553f5cea599b5`) and the same test failed. This evaluator checks manifest declarations, package/file names, shared infrastructure, preserved dependencies and selected path presence/absence; it does not prove module implementation semantics or import behavior.

Method P produced `ADD REP_A01_ARCH_MODULE_STRUCTURE_CI` for `AC_MODULE_STRUCTURE` and `REPLACE REP_A0_ARCH_CI_LAYERING` with `REP_A01_ARCH_INTERNAL_LAYERING_CI` for `AC_LAYERING`. Full candidate validation is `valid`; candidate canonical SHA-256 is `55061a7651faff4d2156bfe1c9734507b521c95be16e7f884114df17e28ae37e` and candidate file-byte SHA-256 is `1f58103112ace2b360b9efcfe806e2f846a31e9f7314b31a25e4780217e5dbce`.

Unchanged B0 Import Linter remains inconclusive: its frozen config references absent `app.repositories`, exits 1, and emits no contract result (95,177,666 ns). B0 has no module-structure representation. This run therefore does not establish comparative detection superiority. Governance remains `HOLD`; G1=`INCOMPLETE`, G4=`NOT AUTHORIZED`, and `P_ALGORITHM_STATUS=NOT_READY`.

## Inherited evaluator observations

The primary inherited run is `pilot02-inherited-semantic-20261020-v6k`; its linked EXP-01 run is `pilot02-inherited-semantic-20261020-v6k-exp01`. The evaluator-results file SHA-256 is `d33c107eb8659b28177d8cc37487e4fdefb1b66a280ad1ab23b8890db846b2d9`; the original run inventory SHA-256 is `62f453717ca91a38f3719428cbc20c69262746a560ddef49cb575ca333b79ba1`; the run-manifest SHA-256 is `893411e5168c616aea477fec7122e27e4142f66da9cfa2f18bb49d65522e0395`.

- Locust: p95 23 ms over 137 requests, 0 failures; p50 13 ms, p99 33 ms; 30,293,681,125 ns; `NOT_EVALUATED` because no threshold is configured.
- Prometheus duration histogram: 153 series (135 buckets, 9 counts, 9 sums); business count delta 73 and sum delta 0.607506125 seconds over the sampling interval. No quantile was inferred.
- Integration: targeted pytest node passed (1 passed, 0 failed/errors/skipped) in 1,416,900,709 ns using isolated disposable `evofit_pilot02_test`.
- Runtime failures: 73 business requests were observed, but matching 5xx and business-operation-failure samples were missing; result is `UNKNOWN`, with no zero rate inferred.

The app endpoint stayed bound to one container, but authoritative application source-to-image revision provenance was unavailable. The runtime collector and adapters are A0.1 DEVELOPMENT artifacts, not frozen A0 executables.

## Timing

`run_adaptation()` took 213,271,916 ns. The two post-materialization candidate evaluator processes took 93,589,625 ns (Import Linter) and 239,742,000 ns (module-structure pytest), 333,331,625 ns combined. Adaptation plus those evaluator processes is 546,603,541 ns. B0's 95,177,666 ns is not a directly comparable workload because it was a single invalid-scope evaluator execution.

## Reproduction

Use source revision `24e9fb91161523377946e16fe5699e49955c2db4`, the exact files under `source_files/`, and the project’s disposable Docker/PostgreSQL prerequisites. The following commands were used in the recorded environment (the Python path may need to point to the project environment):

```bash
python -m experiments.pilots.pilot02_semantic_validation \
  --architecture-source-sha 24e9fb91161523377946e16fe5699e49955c2db4 \
  --output-dir /private/tmp/pilot02-semantic-20261020-v6j

docker compose --project-name evofit-pilot02-20261020-v6k up -d --build --wait
docker compose --project-name evofit-pilot02-20261020-v6k exec -T postgres createdb -U evofit evofit_pilot02_test

python -m experiments.pilots.run_pilot02_inherited_evaluators \
  --base-url http://localhost:8000 \
  --test-database-url postgresql+psycopg://evofit:evofit@localhost:5432/evofit_pilot02_test \
  --compose-project evofit-pilot02-20261020-v6k \
  --run-id semantic-20261020-v6k --skip-method-p

python -m experiments.pilots.run_pilot02_method_p \
  --exp02-run-dir experiments/results/pilot02-inherited-semantic-20261020-v6k-exp01 \
  --output-dir /private/tmp/pilot02-method-20261020-v6k \
  --profile-version 2 --test-only-continuation \
  --test-only-assumptions experiments/pilots/PILOT_02_DEVELOPMENT_ASSUMPTIONS_V2.json \
  --semantic-verification-dir /private/tmp/pilot02-semantic-20261020-v6j
```

The recorded setup created and verified the dedicated test database before starting the inherited-evaluator run. The actual runtime/container source binding remains unverified; reproducing the commands does not remove that provenance limitation.

## Superseded attempts

`attempts/v6g` and `attempts/v6h` preserve intermediate runs superseded after semantic-verifier/scope defects and candidate readback mismatch. `attempts/v6j` preserves the inherited-evaluator attempt whose fresh Compose database did not contain `evofit_pilot02_test`; its semantic controls are the source-bound final controls and are duplicated in `primary/semantic_verification`. They are retained for traceability and excluded from primary measurement.

## Integrity

`SHA256SUMS` lists the SHA-256 digest and size of every other archived file, relative to this archive root. The adjacent repository sidecar `PILOT_02_RAW_EVIDENCE_CONTINUATION_V6.zip.sha256` authenticates the complete ZIP bytes. Existing V1–V5 archives are separate and unchanged.
