"""Audit capability module."""
