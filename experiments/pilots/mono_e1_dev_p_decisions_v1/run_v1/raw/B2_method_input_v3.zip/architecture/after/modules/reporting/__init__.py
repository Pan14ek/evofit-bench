"""Reporting capability module."""
