"""Capability-oriented business modules."""
