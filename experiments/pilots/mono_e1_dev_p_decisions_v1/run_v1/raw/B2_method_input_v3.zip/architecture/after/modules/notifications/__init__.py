"""Notification capability module."""
