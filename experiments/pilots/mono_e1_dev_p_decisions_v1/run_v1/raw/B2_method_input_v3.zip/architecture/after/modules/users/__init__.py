"""User capability module."""
