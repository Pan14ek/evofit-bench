"""Task capability module."""
