PILOT-02 raw evidence archive
Created 2026-10-19 for the development-only A0 to A0.1 architecture-compliance pilot.

Formal run:
- exp02/pilot02-a01-ci-20261019-final contains the validated EXP-02 source bundle, raw evaluator outputs, pinned input artifacts, and manifests.
- method-p/final contains the successful Method P V3 input, trace, candidate configuration, raw outputs, and run manifest.
- controlled-s1 contains the pre-existing PILOT-01 S1 control commands, outputs, and digest manifest. It is a template/evaluator control, not a P candidate run.

harness-repair-attempts contains incomplete diagnostic attempts r3 and r4. These attempts lack successful final manifests and are excluded from all formal results and interpretation. The formal result uses only method-p/final and the matching final EXP-02 bundle above.

Every file other than this SHA256SUMS file is listed with its SHA-256 digest in SHA256SUMS. The companion file outside this archive authenticates this ZIP itself.
No private ground-truth or oracle-side files are included.